"""Unicode Properties from Unicode version 16.0.0 (autogen)."""
